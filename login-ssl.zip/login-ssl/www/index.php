<?php
echo "Hola, mundo";
?>