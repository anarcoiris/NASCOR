import sys
import kafka

print("Python version:", sys.version)
print("Kafka version:", kafka.__version__)
