import tweepy
from kafka import KafkaProducer
import json
import time
import os

# Variables externas
BEARER_TOKEN = os.getenv("BEARER_TOKEN")
QUERY = os.getenv("SEARCH_QUERY", "#tech")
KAFKA_SERVER = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
INITIAL_DELAY = int(os.getenv("INITIAL_DELAY", 0))  # segundos
time.sleep(INITIAL_DELAY)

# Kafka Producer
producer = KafkaProducer(
    bootstrap_servers=KAFKA_SERVER,
    value_serializer=lambda x: json.dumps(x).encode("utf-8")
)

# Twitter Client
client = tweepy.Client(bearer_token=BEARER_TOKEN)

def fetch_tweets():
    tweets = client.search_recent_tweets(query=QUERY, tweet_fields=["created_at", "text", "id"], max_results=10)

    if tweets.data:  # type: ignore
        for tweet in tweets.data:  # type: ignore
            tweet_data = {
                "id": tweet.id,
                "text": tweet.text,
                "timestamp": str(tweet.created_at)
            }
            producer.send("twitter-stream", value=tweet_data)
            print(f"Tweet sent: {tweet_data}")

while True:
    fetch_tweets()
    time.sleep(60)
